package com.example.bangladeshiftar;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.content.ContextCompat;
import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private TextView tvLocation, tvIftarCountdown, tvSuhurTime, tvIftarTime;
    private TextView tvFajr, tvDhuhr, tvAsr, tvMaghrib, tvIsha;
    private FusedLocationProviderClient fusedLocationClient;
    private SharedPreferences prefs;
    private CountDownTimer countDownTimer;
    private ImageView profileIcon;

    private final ActivityResultLauncher<String[]> permissionLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(), result -> fetchLocationAndData());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        
        if (prefs.getBoolean("dark_mode", false)) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }

        setContentView(R.layout.activity_main);
        initViews();
        setupListeners();

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionLauncher.launch(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.POST_NOTIFICATIONS
            });
        } else {
            permissionLauncher.launch(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION
            });
        }
    }

    private void initViews() {
        tvLocation = findViewById(R.id.tvLocation);
        tvIftarCountdown = findViewById(R.id.tvIftarCountdown);
        tvSuhurTime = findViewById(R.id.tvSuhurTime);
        tvIftarTime = findViewById(R.id.tvIftarTime);
        tvFajr = findViewById(R.id.tvFajr);
        tvDhuhr = findViewById(R.id.tvDhuhr);
        tvAsr = findViewById(R.id.tvAsr);
        tvMaghrib = findViewById(R.id.tvMaghrib);
        tvIsha = findViewById(R.id.tvIsha);
        profileIcon = findViewById(R.id.profileIcon);
    }

    private void setupListeners() {
        findViewById(R.id.btnSettings).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        findViewById(R.id.btnDevInfo).setOnClickListener(v -> startActivity(new Intent(this, DevInfoActivity.class)));
        profileIcon.setOnClickListener(v -> startActivity(new Intent(this, ProfileActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateProfilePic();
        fetchLocationAndData();
    }

    private void updateProfilePic() {
        String uriStr = prefs.getString("profile_pic", null);
        if (uriStr != null) {
            try {
                profileIcon.setImageURI(Uri.parse(uriStr));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void fetchLocationAndData() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
                if (location != null) {
                    tvLocation.setText("Current Location");
                    fetchPrayerTimes(location.getLatitude(), location.getLongitude());
                } else {
                    tvLocation.setText("Dhaka (Default)");
                    fetchPrayerTimes(23.8103, 90.4125);
                }
            });
        } else {
            tvLocation.setText("Dhaka (Default)");
            fetchPrayerTimes(23.8103, 90.4125);
            loadCachedData();
        }
    }

    private void fetchPrayerTimes(double lat, double lon) {
        String url = "https://api.aladhan.com/v1/timings/" + (System.currentTimeMillis() / 1000) 
                     + "?latitude=" + lat + "&longitude=" + lon + "&method=1";

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        JSONObject data = response.getJSONObject("data");
                        JSONObject timings = data.getJSONObject("timings");
                        
                        SharedPreferences.Editor editor = prefs.edit();
                        editor.putString("cached_fajr", timings.getString("Fajr"));
                        editor.putString("cached_dhuhr", timings.getString("Dhuhr"));
                        editor.putString("cached_asr", timings.getString("Asr"));
                        editor.putString("cached_maghrib", timings.getString("Maghrib"));
                        editor.putString("cached_isha", timings.getString("Isha"));
                        editor.apply();

                        loadCachedData();
                        
                        Intent widgetIntent = new Intent(this, PrayerWidgetProvider.class);
                        widgetIntent.setAction("android.appwidget.action.APPWIDGET_UPDATE");
                        sendBroadcast(widgetIntent);
                        
                    } catch (Exception e) {
                        loadCachedData();
                    }
                }, error -> loadCachedData());

        ApiClient.getInstance(this).addToRequestQueue(jsonObjectRequest);
    }

    private void loadCachedData() {
        String fajr = prefs.getString("cached_fajr", "04:50");
        String dhuhr = prefs.getString("cached_dhuhr", "12:10");
        String asr = prefs.getString("cached_asr", "15:30");
        String maghrib = prefs.getString("cached_maghrib", "18:00");
        String isha = prefs.getString("cached_isha", "19:15");

        int offset = prefs.getInt("offset_maghrib", 0);
        maghrib = applyOffset(maghrib, offset);

        boolean is24h = prefs.getBoolean("format_24h", false);

        tvSuhurTime.setText(formatTime(fajr, is24h));
        tvIftarTime.setText(formatTime(maghrib, is24h));

        tvFajr.setText(formatTime(fajr, is24h));
        tvDhuhr.setText(formatTime(dhuhr, is24h));
        tvAsr.setText(formatTime(asr, is24h));
        tvMaghrib.setText(formatTime(maghrib, is24h));
        tvIsha.setText(formatTime(isha, is24h));

        startCountdown(maghrib);
        
        scheduleAlarm("Fajr", fajr, 1);
        scheduleAlarm("Dhuhr", dhuhr, 2);
        scheduleAlarm("Asr", asr, 3);
        scheduleAlarm("Maghrib", maghrib, 4);
        scheduleAlarm("Isha", isha, 5);
    }

    private String applyOffset(String time24, int offsetMinutes) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.US);
            Date date = sdf.parse(time24);
            if (date == null) return time24;
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            cal.add(Calendar.MINUTE, offsetMinutes);
            return sdf.format(cal.getTime());
        } catch (Exception e) {
            return time24;
        }
    }

    private String formatTime(String time24, boolean to24h) {
        if (to24h) return time24;
        try {
            SimpleDateFormat sdf24 = new SimpleDateFormat("HH:mm", Locale.US);
            SimpleDateFormat sdf12 = new SimpleDateFormat("hh:mm a", Locale.US);
            Date date = sdf24.parse(time24);
            return date != null ? sdf12.format(date) : time24;
        } catch (Exception e) {
            return time24;
        }
    }

    private void startCountdown(String maghribTime) {
        if (countDownTimer != null) countDownTimer.cancel();
        
        try {
            String[] parts = maghribTime.split(":");
            Calendar target = Calendar.getInstance();
            target.set(Calendar.HOUR_OF_DAY, Integer.parseInt(parts[0]));
            target.set(Calendar.MINUTE, Integer.parseInt(parts[1]));
            target.set(Calendar.SECOND, 0);

            long diff = target.getTimeInMillis() - System.currentTimeMillis();
            if (diff < 0) {
                // If the time has passed today, prepare countdown for tomorrow's maghrib
                target.add(Calendar.DAY_OF_YEAR, 1);
                diff = target.getTimeInMillis() - System.currentTimeMillis();
            }

            countDownTimer = new CountDownTimer(diff, 1000) {
                public void onTick(long millisUntilFinished) {
                    long hours = (millisUntilFinished / (1000 * 60 * 60)) % 24;
                    long minutes = (millisUntilFinished / (1000 * 60)) % 60;
                    long seconds = (millisUntilFinished / 1000) % 60;
                    tvIftarCountdown.setText(String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds));
                }
                public void onFinish() {
                    tvIftarCountdown.setText("It's Iftar Time!");
                }
            }.start();
        } catch (Exception e) {
            tvIftarCountdown.setText("--:--:--");
        }
    }

    private void scheduleAlarm(String name, String time, int reqCode) {
        try {
            String[] parts = time.split(":");
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(parts[0]));
            cal.set(Calendar.MINUTE, Integer.parseInt(parts[1]));
            cal.set(Calendar.SECOND, 0);

            if (cal.getTimeInMillis() < System.currentTimeMillis()) {
                cal.add(Calendar.DAY_OF_YEAR, 1);
            }

            Intent intent = new Intent(this, AlarmReceiver.class);
            intent.putExtra("prayer_name", name);
            PendingIntent pi = PendingIntent.getBroadcast(this, reqCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (am != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                    am.setWindow(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), 60000, pi);
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (countDownTimer != null) countDownTimer.cancel();
    }
}