package com.example.bangladeshiftar;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

public class PrayerWidgetProvider extends AppWidgetProvider {
    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        SharedPreferences prefs = context.getSharedPreferences("AppPrefs", Context.MODE_PRIVATE);
        String iftarTime = prefs.getString("cached_maghrib", "Pending");

        for (int appWidgetId : appWidgetIds) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_prayer);
            views.setTextViewText(R.id.widgetIftarTime, "Iftar: " + iftarTime);
            appWidgetManager.updateAppWidget(appWidgetId, views);
        }
    }
}