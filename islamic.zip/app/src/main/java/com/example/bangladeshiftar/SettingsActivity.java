package com.example.bangladeshiftar;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import com.google.android.material.switchmaterial.SwitchMaterial;

public class SettingsActivity extends AppCompatActivity {
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);

        SwitchMaterial darkSwitch = findViewById(R.id.switchDarkMode);
        SwitchMaterial formatSwitch = findViewById(R.id.switchTimeFormat);
        SwitchMaterial notifSwitch = findViewById(R.id.switchNotifications);
        EditText editOffset = findViewById(R.id.editMaghribOffset);

        darkSwitch.setChecked(prefs.getBoolean("dark_mode", false));
        formatSwitch.setChecked(prefs.getBoolean("format_24h", false));
        notifSwitch.setChecked(prefs.getBoolean("notifications_enabled", true));
        editOffset.setText(String.valueOf(prefs.getInt("offset_maghrib", 0)));

        darkSwitch.setOnCheckedChangeListener((btn, isChecked) -> {
            prefs.edit().putBoolean("dark_mode", isChecked).apply();
            AppCompatDelegate.setDefaultNightMode(isChecked ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);
        });

        formatSwitch.setOnCheckedChangeListener((btn, isChecked) -> prefs.edit().putBoolean("format_24h", isChecked).apply());
        notifSwitch.setOnCheckedChangeListener((btn, isChecked) -> prefs.edit().putBoolean("notifications_enabled", isChecked).apply());

        editOffset.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) {
                try {
                    prefs.edit().putInt("offset_maghrib", Integer.parseInt(s.toString())).apply();
                } catch (Exception e) {}
            }
        });

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }
}