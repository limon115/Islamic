package com.example.bangladeshiftar;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {
    private ImageView profileImage;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        profileImage = findViewById(R.id.profileImageView);
        prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);

        String uriStr = prefs.getString("profile_pic", null);
        if (uriStr != null) {
            try {
                profileImage.setImageURI(Uri.parse(uriStr));
            } catch (Exception e) {}
        }

        ActivityResultLauncher<String[]> picker = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(),
            uri -> {
                if (uri != null) {
                    getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    prefs.edit().putString("profile_pic", uri.toString()).apply();
                    profileImage.setImageURI(uri);
                }
            }
        );

        findViewById(R.id.btnChangeImage).setOnClickListener(v -> picker.launch(new String[]{"image/*"}));
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }
}