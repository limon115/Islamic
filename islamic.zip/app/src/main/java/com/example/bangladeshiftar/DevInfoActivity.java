package com.example.bangladeshiftar;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class DevInfoActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dev_info);
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }
}