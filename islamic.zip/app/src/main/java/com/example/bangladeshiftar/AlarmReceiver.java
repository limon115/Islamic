package com.example.bangladeshiftar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences("AppPrefs", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("notifications_enabled", true)) return;
        
        String prayerName = intent.getStringExtra("prayer_name");
        if (prayerName != null) {
            NotificationHelper.showNotification(context, "Time for " + prayerName, "It is time to offer " + prayerName + " prayer.");
        }
    }
}